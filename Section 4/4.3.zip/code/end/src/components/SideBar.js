import React, { Component } from "react";

class SideBar extends Component {
  render() {
    return (
      <div>
        <h3>Sidebar</h3>
      </div>
    );
  }
}

export default SideBar;
