import React, { Component } from "react";

class Today extends Component {
  render() {
    return (
      <div>
        <h3>Today</h3>
      </div>
    );
  }
}

export default Today;
