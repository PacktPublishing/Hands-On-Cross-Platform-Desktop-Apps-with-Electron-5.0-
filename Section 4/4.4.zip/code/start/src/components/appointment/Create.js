import React, { Component } from "react";

class Create extends Component {
  render() {
    return (
      <div>
        <h3>Create</h3>
      </div>
    );
  }
}

export default Create;
